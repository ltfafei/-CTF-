<script>
$(document).ready(function(){
    $("button").click(function(){
        $.get("/home.php?id=",function(data,status){
            alert("用户: " + data);
        });
    });
});
</script>