<?php
	$dbuser='root';
	$dbpass='c2FkZmFnZGZkc3Nm';
	$host='localhost';
	$db = 'hackimweb200';	
	$con = mysqli_connect($host, $dbuser, $dbpass,$db);
	if (!$con)
    {
        die('Could not connect: ' . mysql_error());
    }
?>
