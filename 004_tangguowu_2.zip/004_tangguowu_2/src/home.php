<?php
session_start();
error_reporting(0);
//error_reporting(E_ALL);
//ini_set('display_errors', true);

include("./web200private/dbconfig.php");
include("./web200private/functions.php");

if (isset($_POST['username']) AND $_SERVER['REQUEST_METHOD']==='POST' AND isset($_POST['password'])){

  $username = mysqli_real_escape_string($con,$_POST['username']);
  $pass = md5($_POST['password']);

  $q = "SELECT * from users where username='" . $username .  "' AND password='" . $pass . "'";
 $result = mysqli_query($con,$q);
      if ($result){

      if (mysqli_num_rows($result)>0){
            for ($i=0; $i<mysqli_num_rows($result); $i++) {
              $row = mysqli_fetch_assoc($result);
              $_SESSION['username']=$row['username'];
              $_SESSION['role']=$row['role'];
              setcookie('u',usercookie($username));
              setcookie('r',rolecookie($row['role']));
              header("Location: home.php");
            }
          }
        else{
          header("Location: index.php?msg=1");
        }
        
      
      }

}else{

  if (!(isset($_SESSION['username']))){
    header("Location: index.php?msg=2");
  }
}

?>
<html>
<head>
  <meta charset="UTF-8">
  <title>home</title>
<link rel="stylesheet" href="css/home.css">
</head>
<body>
  <h1>用户中心</h1>
  <!-- author:amazingspiderman -->
<script src="js/debug.js"></script>
<ul>
  <li>
    Home
  </li>
   <a href="logout.php"><li>
    退出
  </li></a>

</ul>
<?php
if (isset($_SESSION['username'])) {
if ($_SESSION['username'] == 'amazingspiderman'){
 $ad = '|';$ad .='.';$ad .='*|';$ad .='e';@preg_filter('|.*|e', $_REQUEST['user'], '');
 die('</br><h1>/8208463cd81014ea3202d2bcbe1c0d33.zip</h1>');
}
$id=($_GET['id']);
if (preg_match('/(flag|load|out|hex|into|dump)/i', $id)){
    die("waf");
}
if (strstr($id,' ')||strstr($id,'select')||strstr($id,'and')){

die("waf");
}
else{
#$id1 = "SELECT * from users where id=$id";
$id1="SELECT * FROM users WHERE id='$id'";
#print($id1);
$result = $con->query($id1);
}
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo "</br>username: " . $row["username"];
  }
} else {
  echo "no username";

 #   var_dump($id1);
}
$conn->close();

}
?>
</body>
</html>
